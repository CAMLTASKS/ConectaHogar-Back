<?php
/**
 *
 * SugarCRM Community Edition is a customer relationship management program developed by
 * SugarCRM, Inc. Copyright (C) 2004-2013 SugarCRM Inc.
 *
 * SuiteCRM is an extension to SugarCRM Community Edition developed by SalesAgility Ltd.
 * Copyright (C) 2011 - 2018 SalesAgility Ltd.
 *
 * This program is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Affero General Public License version 3 as published by the
 * Free Software Foundation with the addition of the following permission added
 * to Section 15 as permitted in Section 7(a): FOR ANY PART OF THE COVERED WORK
 * IN WHICH THE COPYRIGHT IS OWNED BY SUGARCRM, SUGARCRM DISCLAIMS THE WARRANTY
 * OF NON INFRINGEMENT OF THIRD PARTY RIGHTS.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Affero General Public License for more
 * details.
 *
 * You should have received a copy of the GNU Affero General Public License along with
 * this program; if not, see http://www.gnu.org/licenses or write to the Free
 * Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA
 * 02110-1301 USA.
 *
 * You can contact SugarCRM, Inc. headquarters at 10050 North Wolfe Road,
 * SW2-130, Cupertino, CA 95014, USA. or at email address contact@sugarcrm.com.
 *
 * The interactive user interfaces in modified source and object code versions
 * of this program must display Appropriate Legal Notices, as required under
 * Section 5 of the GNU Affero General Public License version 3.
 *
 * In accordance with Section 7(b) of the GNU Affero General Public License version 3,
 * these Appropriate Legal Notices must retain the display of the "Powered by
 * SugarCRM" logo and "Supercharged by SuiteCRM" logo. If the display of the logos is not
 * reasonably feasible for technical reasons, the Appropriate Legal Notices must
 * display the words "Powered by SugarCRM" and "Supercharged by SuiteCRM".
 */
$mod_strings = array (
  'LBL_ASSIGNED_TO_ID' => 'ID usuario asignado',
  'LBL_ASSIGNED_TO_NAME' => 'Asignado a',
  'LBL_SECURITYGROUPS' => 'Grupos de Seguridad',
  'LBL_SECURITYGROUPS_SUBPANEL_TITLE' => 'Grupos de Seguridad',
  'LBL_ID' => 'ID',
  'LBL_DATE_ENTERED' => 'Fecha creado',
  'LBL_DATE_MODIFIED' => 'Fecha de modificación',
  'LBL_MODIFIED' => 'Modificado por',
  'LBL_MODIFIED_NAME' => 'Modificado por nombre',
  'LBL_CREATED' => 'Creado por',
  'LBL_DESCRIPTION' => 'Mensaje',
  'LBL_DELETED' => 'Eliminado',
  'LBL_NAME' => 'Codigo',
  'LBL_CREATED_USER' => 'Creado por usuario',
  'LBL_MODIFIED_USER' => 'Modificado por usuario',
  'LBL_LIST_NAME' => 'Nombre',
  'LBL_EDIT_BUTTON' => 'Editar',
  'LBL_REMOVE' => 'Quitar',
  'LBL_ASCENDING' => 'Ascendente',
  'LBL_DESCENDING' => 'Descendente',
  'LBL_OPT_IN' => 'Autorizado',
  'LBL_OPT_IN_PENDING_EMAIL_NOT_SENT' => 'Autorización pendiente. Confirmación no enviada',
  'LBL_OPT_IN_PENDING_EMAIL_SENT' => 'Autorización pendiente. Confirmación enviada',
  'LBL_OPT_IN_CONFIRMED' => 'Autorizado',
  'LBL_MODULE_NAME' => 'Mensajes',
  'LBL_MODULE_TITLE' => 'Mensajes',
  'LNK_NEW_DOCUMENT' => 'Nuevo documento',
  'LNK_DOCUMENT_LIST' => 'Lista de documentos',
  'LBL_SEARCH_FORM_TITLE' => 'Búsqueda Mensajes',
  'LBL_ASSIGNED_TO' => 'Asignado a:',
  'LBL_CATEGORY' => 'Categoría',
  'LBL_SUBCATEGORY' => 'Subcategoría',
  'LBL_STATUS' => 'Estado',
  'LBL_IS_TEMPLATE' => 'Es una plantilla',
  'LBL_TEMPLATE_TYPE' => 'Tipo de documento',
  'LBL_REVISION_NAME' => 'Número de versión',
  'LBL_MIME' => 'Tipo MIME',
  'LBL_REVISION' => 'Versión',
  'LBL_DOCUMENT' => 'Documento relacionado',
  'LBL_LATEST_REVISION' => 'Última versión',
  'LBL_CHANGE_LOG' => 'Registro de cambios',
  'LBL_ACTIVE_DATE' => 'Fecha de publicación',
  'LBL_EXPIRATION_DATE' => 'Fecha de expiración',
  'LBL_FILE_EXTENSION' => 'Extensión de archivo',
  'LBL_CAT_OR_SUBCAT_UNSPEC' => 'Sin especificar',
  'LBL_NEW_FORM_TITLE' => 'New Mensajes',
  'LBL_DOC_NAME' => 'Nombre del documento:',
  'LBL_FILENAME' => 'Nombre del archivo:',
  'LBL_FILE_UPLOAD' => 'Archivo:',
  'LBL_DOC_VERSION' => 'Versión:',
  'LBL_CATEGORY_VALUE' => 'Categoría:',
  'LBL_SUBCATEGORY_VALUE' => 'Subcategoría:',
  'LBL_DOC_STATUS' => 'Estado:',
  'LBL_DET_TEMPLATE_TYPE' => 'Tipo de documento:',
  'LBL_DOC_DESCRIPTION' => 'Descripción:',
  'LBL_DOC_ACTIVE_DATE' => 'Fecha de publicación:',
  'LBL_DOC_EXP_DATE' => 'Fecha de expiración:',
  'LBL_LIST_FORM_TITLE' => 'Mensajes List',
  'LBL_LIST_DOCUMENT' => 'Documento',
  'LBL_LIST_CATEGORY' => 'Categoría',
  'LBL_LIST_SUBCATEGORY' => 'Subcategoría',
  'LBL_LIST_REVISION' => 'Revision',
  'LBL_LIST_LAST_REV_CREATOR' => 'Enviado por',
  'LBL_LIST_LAST_REV_DATE' => 'Fecha de versión',
  'LBL_LIST_VIEW_DOCUMENT' => 'Ver',
  'LBL_LIST_ACTIVE_DATE' => 'Publish Date',
  'LBL_LIST_EXP_DATE' => 'Expiration Date',
  'LBL_LIST_STATUS' => 'Estado',
  'LBL_SF_CATEGORY' => 'Category:',
  'LBL_SF_SUBCATEGORY' => 'Sub Category:',
  'DEF_CREATE_LOG' => 'Documento creado',
  'ERR_DOC_NAME' => 'Nombre del documento',
  'ERR_DOC_ACTIVE_DATE' => 'Publish Date',
  'ERR_FILENAME' => 'Nombre del archivo',
  'LBL_LIST_DOCUMENT_NAME' => 'Nombre del documento',
  'LBL_HOMEPAGE_TITLE' => 'Mi Mensajes',
  'LNK_NEW_RECORD' => 'Nuevo Mensajes',
  'LNK_LIST' => 'View Mensajes',
  'LNK_IMPORT_CAML_MENSAJES' => 'Importar Mensajes',
  'LBL_HISTORY_SUBPANEL_TITLE' => 'View History',
  'LBL_ACTIVITIES_SUBPANEL_TITLE' => 'Activities',
  'LBL_CAML_MENSAJES_SUBPANEL_TITLE' => 'Mensajes',
  'LBL_LEIDO' => 'Leido',
  'LBL_FECHA_LEIDO' => 'Fecha y hora leido',
);